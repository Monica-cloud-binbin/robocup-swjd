#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>
#include <string>
#include <vector>

#include <geometry_msgs/Point.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <std_srvs/Trigger.h>
#include <tf/transform_datatypes.h>

namespace
{
const double kPi = 3.14159265358979323846;

enum MissionState
{
    TAKEOFF = 0,
    TRANSIT_START_TO_SATELLITE = 1,
    SATELLITE_SEARCH = 2,
    SATELLITE_CAPTURE = 3,
    SATELLITE_ORBIT = 4,
    TRANSIT_SATELLITE_TO_YELLOW = 5,
    YELLOW_SEARCH = 6,
    YELLOW_APPROACH = 7,
    YELLOW_CONTACT_SPIN = 8,
    TRANSIT_YELLOW_TO_HOME = 9,
    LAND = 10,
    COMPLETE = 11
};

enum HookSide
{
    HOOK_NONE,
    HOOK_LEFT,
    HOOK_RIGHT,
    HOOK_INVALID
};

// MAVROS / odometry state
mavros_msgs::State current_state;
nav_msgs::Odometry local_pos;
bool odom_received = false;
double init_position_x_take_off = 0.0;
double init_position_y_take_off = 0.0;
double init_position_z_take_off = 0.0;
double init_yaw = 0.0;
double roll = 0.0;
double pitch = 0.0;
double yaw = 0.0;

// Existing black-ring interface. point.z remains the original percentage value.
double target_x = 320.0;
double x_center = 320.0;
double bbox_ratio = 0.0;
ros::Time last_target_time;

// Kept for compatibility with the existing depth node; it is not a mission gate.
double depth = 0.0;
double depth_target = 0.385;
double Kp_depth = 1.0;
ros::Time last_depth_time;

// Reserved yellow-balloon interface:
// point.x = horizontal pixel, point.y = vertical pixel, point.z = area ratio [0, 1].
double yellow_target_pixel_x = 320.0;
double yellow_target_pixel_y = 240.0;
double yellow_area_ratio = 0.0;
ros::Time last_yellow_time;

// Coordinates are relative to takeoff in the mission frame:
// +x initial nose direction, +y left, +z up.
double ALTITUDE = 0.825;
double position_x = 2.0;  // Legacy satellite x parameter.
double position_y = -2.0; // Legacy satellite y parameter.
double satellite_x = 2.0;
double satellite_y = -2.0;
double satellite_z = 0.825;
double yellow_balloon_x = 4.0;
double yellow_balloon_y = -2.0;
double yellow_balloon_z = 0.825;
double red_balloon_x = 3.0;
double red_balloon_y = -1.0;
double red_balloon_z = 0.825;

// Existing ring feedback controller.
double Kp_fast = 0.00035;
double Kp_slow = 0.00020;
double Kp = 0.0025;
double Kd = 0.0003;
double aspect_threshold = 1.1;
double delta_omega = 0.05;
double omega_base = 0.137;

// Legacy radius parameters are loaded first, then used as defaults for the new names.
double R_circle_0 = 1.7;
double R_circle_1 = 1.0;
double R_circle_2 = 1.0;
double R_circle_3 = 1.0;
double R_circle_4 = 1.5;
double R_satellite_search = 1.7;
double R_satellite_capture = 1.0;
double R_satellite_orbit = 1.0;
double R_satellite_exit = 1.5;

// Black-ring state parameters.
double ring_target_x_min = 245.0;
double ring_target_x_max = 370.0;
int ring_detect_count_required = 6;
double ring_message_timeout = 0.5;
double satellite_capture_duration = 12.0;
double satellite_orbit_duration = 12.0;
double satellite_vision_loss_timeout = 2.0;
double satellite_search_timeout = 60.0;

// Yellow-balloon state parameters.
double yellow_target_x = 320.0;
double yellow_center_tolerance = 30.0;
double yellow_message_timeout = 0.5;
double yellow_area_slow_threshold = 0.10;
double yellow_area_contact_threshold = 0.25;
double yellow_search_yaw_rate = 0.20;
double yellow_contact_spin_rate = 0.80;
double yellow_contact_spin_duration = 5.0;
double yellow_contact_forward_speed = 0.0;
double yellow_approach_speed = 0.25;
double yellow_slow_approach_speed = 0.08;
double yellow_yaw_kp = 0.002;
double yellow_loss_return_timeout = 1.0;
double yellow_search_timeout = 60.0;
double yellow_approach_timeout = 30.0;
int yellow_detect_count_required = 3;

// Transit / hook parameters.
std::string start_to_satellite_hook = "NONE";
std::string satellite_to_yellow_hook = "NONE";
std::string yellow_to_home_hook = "NONE";
double hook_safe_radius = 1.0;
double hook_arc_step = 0.15; // Angular sampling step, rad.
double waypoint_tolerance = 0.20;
double transit_timeout = 60.0;

// task_num intentionally remains the central state number.
MissionState task_num = TAKEOFF;
ros::Time task_start_time;
bool state_entry_pending = true;
std::vector<geometry_msgs::Point> active_path;
std::size_t active_waypoint_index = 0;
bool active_path_valid = false;
geometry_msgs::Point hold_point;
double circle_theta = 0.0;
double omega_circle = 0.0;
double last_ring_error_x = 0.0;
int ring_detect_count = 0;
int yellow_detect_count = 0;
double commanded_yaw = 0.0;
geometry_msgs::Point commanded_position;
double contact_forward_yaw = 0.0;
bool land_request_sent = false;
ros::Time last_land_request;

ros::ServiceClient set_mode_client;
ros::ServiceClient capture_voice_client;
ros::ServiceClient orbit_voice_client;
ros::ServiceClient yellow_voice_client;

const char* stateName(MissionState state)
{
    switch (state)
    {
        case TAKEOFF: return "TAKEOFF";
        case TRANSIT_START_TO_SATELLITE: return "TRANSIT_START_TO_SATELLITE";
        case SATELLITE_SEARCH: return "SATELLITE_SEARCH";
        case SATELLITE_CAPTURE: return "SATELLITE_CAPTURE";
        case SATELLITE_ORBIT: return "SATELLITE_ORBIT";
        case TRANSIT_SATELLITE_TO_YELLOW: return "TRANSIT_SATELLITE_TO_YELLOW";
        case YELLOW_SEARCH: return "YELLOW_SEARCH";
        case YELLOW_APPROACH: return "YELLOW_APPROACH";
        case YELLOW_CONTACT_SPIN: return "YELLOW_CONTACT_SPIN";
        case TRANSIT_YELLOW_TO_HOME: return "TRANSIT_YELLOW_TO_HOME";
        case LAND: return "LAND";
        case COMPLETE: return "COMPLETE";
    }
    return "UNKNOWN";
}

double clampValue(double value, double low, double high)
{
    return std::max(low, std::min(value, high));
}

double normalizePositive(double angle)
{
    while (angle < 0.0) angle += 2.0 * kPi;
    while (angle >= 2.0 * kPi) angle -= 2.0 * kPi;
    return angle;
}

double distance3d(const geometry_msgs::Point& a, const geometry_msgs::Point& b)
{
    const double dx = a.x - b.x;
    const double dy = a.y - b.y;
    const double dz = a.z - b.z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

geometry_msgs::Point currentPoint()
{
    return local_pos.pose.pose.position;
}

geometry_msgs::Quaternion quaternionFromYaw(double yaw_value)
{
    tf::Quaternion q;
    q.setRPY(0.0, 0.0, yaw_value);
    q.normalize();
    geometry_msgs::Quaternion result;
    tf::quaternionTFToMsg(q, result);
    return result;
}

geometry_msgs::Point missionToLocal(double mission_x, double mission_y, double mission_z)
{
    geometry_msgs::Point result;
    result.x = init_position_x_take_off + mission_x * std::cos(init_yaw)
             - mission_y * std::sin(init_yaw);
    result.y = init_position_y_take_off + mission_x * std::sin(init_yaw)
             + mission_y * std::cos(init_yaw);
    result.z = init_position_z_take_off + mission_z;
    return result;
}

geometry_msgs::Point satelliteCenter()
{
    return missionToLocal(satellite_x, satellite_y, satellite_z);
}

geometry_msgs::Point yellowSearchPoint()
{
    return missionToLocal(yellow_balloon_x, yellow_balloon_y, yellow_balloon_z);
}

geometry_msgs::Point redBalloonPoint()
{
    return missionToLocal(red_balloon_x, red_balloon_y, red_balloon_z);
}

geometry_msgs::Point homeHoverPoint()
{
    return missionToLocal(0.0, 0.0, ALTITUDE);
}

void state_cb(const mavros_msgs::State::ConstPtr& msg)
{
    current_state = *msg;
}

void local_pos_cb(const nav_msgs::Odometry::ConstPtr& msg)
{
    const geometry_msgs::Point& p = msg->pose.pose.position;
    const geometry_msgs::Quaternion& q_msg = msg->pose.pose.orientation;
    const double q_norm_sq = q_msg.x * q_msg.x + q_msg.y * q_msg.y
                           + q_msg.z * q_msg.z + q_msg.w * q_msg.w;
    if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)
        || !std::isfinite(q_norm_sq) || q_norm_sq < 1.0e-8)
    {
        ROS_WARN_THROTTLE(1.0, "Ignoring invalid odometry sample");
        return;
    }

    local_pos = *msg;
    tf::Quaternion q;
    tf::quaternionMsgToTF(q_msg, q);
    q.normalize();
    tf::Matrix3x3(q).getRPY(roll, pitch, yaw);

    // The first valid message defines the mission origin, even when ground z is exactly 0.
    if (!odom_received)
    {
        init_position_x_take_off = p.x;
        init_position_y_take_off = p.y;
        init_position_z_take_off = p.z;
        init_yaw = yaw;
        odom_received = true;
        ROS_INFO("Mission origin captured: x=%.3f y=%.3f z=%.3f yaw=%.3f",
                 init_position_x_take_off, init_position_y_take_off,
                 init_position_z_take_off, init_yaw);
    }
}

void object_position_cb(const geometry_msgs::PointStamped::ConstPtr& msg)
{
    // Keep the original black-ring message convention: z is percentage (e.g. 110 -> 1.10).
    bbox_ratio = msg->point.z / 100.0;
    target_x = msg->point.x;
    last_target_time = ros::Time::now();
}

void depth_object_position_cb(const geometry_msgs::PointStamped::ConstPtr& msg)
{
    depth = msg->point.z;
    last_depth_time = ros::Time::now();
}

void yellow_balloon_cb(const geometry_msgs::PointStamped::ConstPtr& msg)
{
    yellow_target_pixel_x = msg->point.x;
    yellow_target_pixel_y = msg->point.y;
    yellow_area_ratio = clampValue(msg->point.z, 0.0, 1.0);
    last_yellow_time = ros::Time::now();
}

bool ringMessageFresh()
{
    return !last_target_time.isZero()
        && ros::Time::now() - last_target_time < ros::Duration(ring_message_timeout);
}

bool ringCenteredAndFresh()
{
    return ringMessageFresh() && target_x >= ring_target_x_min && target_x <= ring_target_x_max;
}

bool yellowMessageFresh()
{
    return !last_yellow_time.isZero()
        && ros::Time::now() - last_yellow_time < ros::Duration(yellow_message_timeout);
}

HookSide parseHookSide(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(),
                   [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    if (value == "NONE") return HOOK_NONE;
    if (value == "LEFT") return HOOK_LEFT;
    if (value == "RIGHT") return HOOK_RIGHT;
    return HOOK_INVALID;
}

bool tangentPoints(const geometry_msgs::Point& external,
                   const geometry_msgs::Point& center,
                   double radius,
                   std::vector<geometry_msgs::Point>& tangents)
{
    const double dx = external.x - center.x;
    const double dy = external.y - center.y;
    const double distance = std::sqrt(dx * dx + dy * dy);
    if (distance <= radius + 1.0e-6)
        return false;

    const double base = std::atan2(dy, dx);
    const double offset = std::acos(clampValue(radius / distance, -1.0, 1.0));
    for (int sign = -1; sign <= 1; sign += 2)
    {
        const double angle = base + sign * offset;
        geometry_msgs::Point tangent;
        tangent.x = center.x + radius * std::cos(angle);
        tangent.y = center.y + radius * std::sin(angle);
        tangent.z = external.z;
        tangents.push_back(tangent);
    }
    return true;
}

// Build a fixed horizontal tangent-arc-tangent path around the red balloon.
// LEFT/RIGHT is defined relative to the start-to-goal travel direction.
std::vector<geometry_msgs::Point> buildHookPath(
    const geometry_msgs::Point& start,
    const geometry_msgs::Point& goal,
    const geometry_msgs::Point& red_balloon,
    double safe_radius,
    HookSide side,
    double arc_step)
{
    std::vector<geometry_msgs::Point> result;
    if (side == HOOK_NONE)
    {
        result.push_back(goal);
        return result;
    }
    if (side != HOOK_LEFT && side != HOOK_RIGHT)
    {
        ROS_ERROR("Invalid hook side");
        return result;
    }
    if (safe_radius <= 0.0 || arc_step <= 0.0)
    {
        ROS_ERROR("hook_safe_radius and hook_arc_step must be positive");
        return result;
    }

    const double route_dx = goal.x - start.x;
    const double route_dy = goal.y - start.y;
    const double route_length = std::sqrt(route_dx * route_dx + route_dy * route_dy);
    if (route_length < 1.0e-6)
    {
        ROS_ERROR("Cannot build hook path: start and goal coincide");
        return result;
    }

    std::vector<geometry_msgs::Point> start_tangents;
    std::vector<geometry_msgs::Point> goal_tangents;
    if (!tangentPoints(start, red_balloon, safe_radius, start_tangents)
        || !tangentPoints(goal, red_balloon, safe_radius, goal_tangents))
    {
        ROS_ERROR("Cannot build hook path: start or goal is inside the red-balloon safe circle. Holding position.");
        return result;
    }

    struct Candidate
    {
        geometry_msgs::Point entry;
        geometry_msgs::Point exit;
        double entry_angle;
        double delta_angle;
        double score;
        Candidate() : entry_angle(0.0), delta_angle(0.0), score(std::numeric_limits<double>::infinity()) {}
    } best;

    const double dir_x = route_dx / route_length;
    const double dir_y = route_dy / route_length;
    const double requested_sign = side == HOOK_LEFT ? 1.0 : -1.0;

    for (std::size_t i = 0; i < start_tangents.size(); ++i)
    {
        for (std::size_t j = 0; j < goal_tangents.size(); ++j)
        {
            const double a1 = std::atan2(start_tangents[i].y - red_balloon.y,
                                         start_tangents[i].x - red_balloon.x);
            const double a2 = std::atan2(goal_tangents[j].y - red_balloon.y,
                                         goal_tangents[j].x - red_balloon.x);
            const double ccw_delta = normalizePositive(a2 - a1);
            const double deltas[2] = {ccw_delta, ccw_delta - 2.0 * kPi};

            for (int direction = 0; direction < 2; ++direction)
            {
                const double delta = deltas[direction];
                const double travel_sign = delta >= 0.0 ? 1.0 : -1.0;
                const double mid_angle = a1 + 0.5 * delta;
                const double mid_x = red_balloon.x + safe_radius * std::cos(mid_angle);
                const double mid_y = red_balloon.y + safe_radius * std::sin(mid_angle);
                const double lateral = dir_x * (mid_y - start.y) - dir_y * (mid_x - start.x);

                const double in_dx = start_tangents[i].x - start.x;
                const double in_dy = start_tangents[i].y - start.y;
                const double in_length = std::sqrt(in_dx * in_dx + in_dy * in_dy);
                const double out_dx = goal.x - goal_tangents[j].x;
                const double out_dy = goal.y - goal_tangents[j].y;
                const double out_length = std::sqrt(out_dx * out_dx + out_dy * out_dy);
                const double tangent1_x = travel_sign * -std::sin(a1);
                const double tangent1_y = travel_sign *  std::cos(a1);
                const double tangent2_x = travel_sign * -std::sin(a2);
                const double tangent2_y = travel_sign *  std::cos(a2);
                const double alignment_in = (in_dx * tangent1_x + in_dy * tangent1_y) / in_length;
                const double alignment_out = (out_dx * tangent2_x + out_dy * tangent2_y) / out_length;

                double score = in_length + std::fabs(delta) * safe_radius + out_length;
                if (requested_sign * lateral <= 0.0) score += 10000.0;
                if (alignment_in < 0.5) score += 1000.0;
                if (alignment_out < 0.5) score += 1000.0;

                if (score < best.score)
                {
                    best.entry = start_tangents[i];
                    best.exit = goal_tangents[j];
                    best.entry_angle = a1;
                    best.delta_angle = delta;
                    best.score = score;
                }
            }
        }
    }

    if (!std::isfinite(best.score))
    {
        ROS_ERROR("No finite tangent/arc hook path could be constructed. Holding position.");
        return result;
    }

    best.entry.z = goal.z;
    best.exit.z = goal.z;
    result.push_back(best.entry);
    const int arc_samples = std::max(1, static_cast<int>(std::ceil(std::fabs(best.delta_angle) / arc_step)));
    for (int i = 1; i <= arc_samples; ++i)
    {
        const double fraction = static_cast<double>(i) / static_cast<double>(arc_samples);
        const double angle = best.entry_angle + best.delta_angle * fraction;
        geometry_msgs::Point waypoint;
        waypoint.x = red_balloon.x + safe_radius * std::cos(angle);
        waypoint.y = red_balloon.y + safe_radius * std::sin(angle);
        waypoint.z = goal.z;
        if (result.empty() || distance3d(result.back(), waypoint) > 1.0e-6)
            result.push_back(waypoint);
    }
    if (result.empty() || distance3d(result.back(), goal) > 1.0e-6)
        result.push_back(goal);

    ROS_INFO("Built %s hook path with %zu waypoints",
             side == HOOK_LEFT ? "LEFT" : "RIGHT", result.size());
    return result;
}

geometry_msgs::Point circleEntryPoint(const geometry_msgs::Point& center, double radius)
{
    geometry_msgs::Point current = currentPoint();
    double dx = current.x - center.x;
    double dy = current.y - center.y;
    double length = std::sqrt(dx * dx + dy * dy);
    if (length < 1.0e-6)
    {
        dx = -std::cos(init_yaw);
        dy = -std::sin(init_yaw);
        length = 1.0;
    }
    geometry_msgs::Point result;
    result.x = center.x + radius * dx / length;
    result.y = center.y + radius * dy / length;
    result.z = center.z;
    return result;
}

void enterState(MissionState next_state)
{
    task_num = next_state;
    task_start_time = ros::Time::now();
    state_entry_pending = true;
    ROS_INFO("Entering state %d: %s", static_cast<int>(task_num), stateName(task_num));
}

void callVoiceOnce(ros::ServiceClient& client, const char* description)
{
    std_srvs::Trigger trigger;
    if (!client.call(trigger))
        ROS_WARN("Voice service unavailable for: %s", description);
    else if (!trigger.response.success)
        ROS_WARN("Voice service rejected: %s (%s)", description, trigger.response.message.c_str());
}

bool prepareTransit(const geometry_msgs::Point& goal, const std::string& configured_side)
{
    hold_point = currentPoint();
    const HookSide side = parseHookSide(configured_side);
    if (side == HOOK_INVALID)
    {
        ROS_ERROR("Invalid hook mode '%s'; expected NONE, LEFT or RIGHT. Holding position.",
                  configured_side.c_str());
        active_path.clear();
        active_path_valid = false;
        return false;
    }

    active_path = buildHookPath(currentPoint(), goal, redBalloonPoint(),
                                hook_safe_radius, side, hook_arc_step);
    active_waypoint_index = 0;
    active_path_valid = !active_path.empty();
    if (!active_path_valid)
        ROS_ERROR("Transit path is invalid; vehicle will hold its current position");
    return active_path_valid;
}

void setPose(geometry_msgs::PoseStamped& pose,
             const geometry_msgs::Point& point,
             double yaw_setpoint)
{
    pose.header.stamp = ros::Time::now();
    pose.pose.position = point;
    pose.pose.orientation = quaternionFromYaw(yaw_setpoint);
}

bool updateTransitPose(geometry_msgs::PoseStamped& pose)
{
    if (!active_path_valid || active_waypoint_index >= active_path.size())
    {
        setPose(pose, hold_point, yaw);
        return false;
    }

    while (active_waypoint_index < active_path.size()
           && distance3d(currentPoint(), active_path[active_waypoint_index]) <= waypoint_tolerance)
    {
        ++active_waypoint_index;
    }
    if (active_waypoint_index >= active_path.size())
        return true;

    const geometry_msgs::Point& waypoint = active_path[active_waypoint_index];
    const double face_yaw = std::atan2(waypoint.y - local_pos.pose.pose.position.y,
                                      waypoint.x - local_pos.pose.pose.position.x);
    setPose(pose, waypoint, face_yaw);
    return false;
}

double updateRingOmega(double dt)
{
    if (!ringMessageFresh())
    {
        last_ring_error_x = 0.0;
        return omega_base;
    }

    double error_x = clampValue(target_x - x_center, -200.0, 200.0);
    Kp = error_x > 0.0 ? Kp_fast : Kp_slow;
    const double derivative = dt > 1.0e-4 ? (error_x - last_ring_error_x) / dt : 0.0;
    last_ring_error_x = error_x;
    double omega = omega_base + Kp * error_x + Kd * derivative;

    if (bbox_ratio > aspect_threshold)
        omega += target_x < x_center ? -delta_omega : delta_omega;

    return clampValue(omega, 0.02, 0.25);
}

void setCirclePose(geometry_msgs::PoseStamped& pose,
                   const geometry_msgs::Point& center,
                   double radius,
                   double omega,
                   double dt)
{
    circle_theta += omega * dt;
    geometry_msgs::Point target;
    target.x = center.x + radius * std::cos(circle_theta);
    target.y = center.y + radius * std::sin(circle_theta);
    target.z = center.z;
    const double face_center_yaw = std::atan2(center.y - local_pos.pose.pose.position.y,
                                             center.x - local_pos.pose.pose.position.x);
    setPose(pose, target, face_center_yaw);
}

void initializeCircle(const geometry_msgs::Point& center)
{
    circle_theta = std::atan2(local_pos.pose.pose.position.y - center.y,
                              local_pos.pose.pose.position.x - center.x);
    last_ring_error_x = 0.0;
}

void requestLandMode()
{
    mavros_msgs::SetMode land_mode;
    land_mode.request.custom_mode = "AUTO.LAND";
    if (set_mode_client.call(land_mode) && land_mode.response.mode_sent)
    {
        land_request_sent = true;
        ROS_INFO("AUTO.LAND enabled");
    }
    else
    {
        ROS_WARN("AUTO.LAND request failed; will retry");
    }
    last_land_request = ros::Time::now();
}

void loadParameters(ros::NodeHandle& private_nh)
{
    private_nh.param("ALTITUDE", ALTITUDE, 0.825);
    private_nh.param("position_x", position_x, 2.0);
    private_nh.param("position_y", position_y, -2.0);
    private_nh.param("satellite_x", satellite_x, position_x);
    private_nh.param("satellite_y", satellite_y, position_y);
    private_nh.param("satellite_z", satellite_z, ALTITUDE);
    private_nh.param("yellow_balloon_x", yellow_balloon_x, 4.0);
    private_nh.param("yellow_balloon_y", yellow_balloon_y, -2.0);
    private_nh.param("yellow_balloon_z", yellow_balloon_z, ALTITUDE);
    private_nh.param("red_balloon_x", red_balloon_x, 3.0);
    private_nh.param("red_balloon_y", red_balloon_y, -1.0);
    private_nh.param("red_balloon_z", red_balloon_z, ALTITUDE);

    private_nh.param("Kp_fast", Kp_fast, 0.00035);
    private_nh.param("Kp_slow", Kp_slow, 0.00020);
    private_nh.param("Kp", Kp, 0.0025);
    private_nh.param("Kd", Kd, 0.0003);
    private_nh.param("aspect_threshold", aspect_threshold, 1.1);
    private_nh.param("delta_omega", delta_omega, 0.05);
    private_nh.param("omega_base", omega_base, 0.137);
    private_nh.param("depth_target", depth_target, 0.385);
    private_nh.param("Kp_depth", Kp_depth, 1.0);

    private_nh.param("R_circle_0", R_circle_0, 1.7);
    private_nh.param("R_circle_1", R_circle_1, 1.0);
    private_nh.param("R_circle_2", R_circle_2, 1.0);
    private_nh.param("R_circle_3", R_circle_3, 1.0);
    private_nh.param("R_circle_4", R_circle_4, 1.5);
    private_nh.param("R_satellite_search", R_satellite_search, R_circle_0);
    private_nh.param("R_satellite_capture", R_satellite_capture, R_circle_1);
    private_nh.param("R_satellite_orbit", R_satellite_orbit, R_circle_2);
    private_nh.param("R_satellite_exit", R_satellite_exit, R_circle_4);

    private_nh.param("ring_target_x_min", ring_target_x_min, 245.0);
    private_nh.param("ring_target_x_max", ring_target_x_max, 370.0);
    private_nh.param("ring_detect_count_required", ring_detect_count_required, 6);
    private_nh.param("ring_message_timeout", ring_message_timeout, 0.5);
    private_nh.param("satellite_capture_duration", satellite_capture_duration, 12.0);
    private_nh.param("satellite_orbit_duration", satellite_orbit_duration, 12.0);
    private_nh.param("satellite_vision_loss_timeout", satellite_vision_loss_timeout, 2.0);
    private_nh.param("satellite_search_timeout", satellite_search_timeout, 60.0);

    private_nh.param("yellow_target_x", yellow_target_x, 320.0);
    private_nh.param("yellow_center_tolerance", yellow_center_tolerance, 30.0);
    private_nh.param("yellow_message_timeout", yellow_message_timeout, 0.5);
    private_nh.param("yellow_area_slow_threshold", yellow_area_slow_threshold, 0.10);
    private_nh.param("yellow_area_contact_threshold", yellow_area_contact_threshold, 0.25);
    private_nh.param("yellow_search_yaw_rate", yellow_search_yaw_rate, 0.20);
    private_nh.param("yellow_contact_spin_rate", yellow_contact_spin_rate, 0.80);
    private_nh.param("yellow_contact_spin_duration", yellow_contact_spin_duration, 5.0);
    private_nh.param("yellow_contact_forward_speed", yellow_contact_forward_speed, 0.0);
    private_nh.param("yellow_approach_speed", yellow_approach_speed, 0.25);
    private_nh.param("yellow_slow_approach_speed", yellow_slow_approach_speed, 0.08);
    private_nh.param("yellow_yaw_kp", yellow_yaw_kp, 0.002);
    private_nh.param("yellow_loss_return_timeout", yellow_loss_return_timeout, 1.0);
    private_nh.param("yellow_search_timeout", yellow_search_timeout, 60.0);
    private_nh.param("yellow_approach_timeout", yellow_approach_timeout, 30.0);
    private_nh.param("yellow_detect_count_required", yellow_detect_count_required, 3);

    private_nh.param("start_to_satellite_hook", start_to_satellite_hook, std::string("NONE"));
    private_nh.param("satellite_to_yellow_hook", satellite_to_yellow_hook, std::string("NONE"));
    private_nh.param("yellow_to_home_hook", yellow_to_home_hook, std::string("NONE"));
    private_nh.param("hook_safe_radius", hook_safe_radius, 1.0);
    private_nh.param("hook_arc_step", hook_arc_step, 0.15);
    private_nh.param("waypoint_tolerance", waypoint_tolerance, 0.20);
    private_nh.param("transit_timeout", transit_timeout, 60.0);

    ROS_INFO("Mission parameters loaded. Satellite=(%.2f, %.2f, %.2f), Yellow=(%.2f, %.2f, %.2f), Red=(%.2f, %.2f)",
             satellite_x, satellite_y, satellite_z,
             yellow_balloon_x, yellow_balloon_y, yellow_balloon_z,
             red_balloon_x, red_balloon_y);
    ROS_INFO("Satellite radii search/capture/orbit/exit = %.2f / %.2f / %.2f / %.2f",
             R_satellite_search, R_satellite_capture, R_satellite_orbit, R_satellite_exit);
}
} // namespace

int main(int argc, char** argv)
{
    ros::init(argc, argv, "offboard_multi_position");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");
    loadParameters(private_nh);

    ros::Subscriber object_pos_sub = nh.subscribe<geometry_msgs::PointStamped>(
        "/object_position", 10, object_position_cb);
    ros::Subscriber depth_object_pos_sub = nh.subscribe<geometry_msgs::PointStamped>(
        "/depth_object_position", 10, depth_object_position_cb);
    ros::Subscriber yellow_pos_sub = nh.subscribe<geometry_msgs::PointStamped>(
        "/yellow_balloon_position", 10, yellow_balloon_cb);
    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>(
        "mavros/state", 10, state_cb);
    ros::Subscriber local_pos_sub = nh.subscribe<nav_msgs::Odometry>(
        "mavros/local_position/odom", 10, local_pos_cb);

    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>(
        "mavros/setpoint_position/local", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>(
        "mavros/cmd/arming");
    set_mode_client = nh.serviceClient<mavros_msgs::SetMode>("mavros/set_mode");
    capture_voice_client = nh.serviceClient<std_srvs::Trigger>("play1");
    orbit_voice_client = nh.serviceClient<std_srvs::Trigger>("play2");
    yellow_voice_client = nh.serviceClient<std_srvs::Trigger>("play3");

    ros::Rate rate(20.0);
    while (ros::ok() && !current_state.connected)
    {
        ROS_INFO_THROTTLE(2.0, "Waiting for FCU connection...");
        ros::spinOnce();
        rate.sleep();
    }

    // A valid odometry sample is mandatory before constructing the takeoff setpoint.
    while (ros::ok() && !odom_received)
    {
        ROS_INFO_THROTTLE(2.0, "Waiting for valid local odometry...");
        ros::spinOnce();
        rate.sleep();
    }
    if (!ros::ok()) return 0;

    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = "map";
    setPose(pose, homeHoverPoint(), init_yaw);

    // PX4 requires a stream of setpoints before OFFBOARD can be requested.
    for (int i = 100; ros::ok() && i > 0; --i)
    {
        pose.header.stamp = ros::Time::now();
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }

    mavros_msgs::SetMode offboard_mode;
    offboard_mode.request.custom_mode = "OFFBOARD";
    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;
    ros::Time last_mode_request;
    ros::Time last_arm_request;
    ros::Time takeoff_reached_time;
    ROS_INFO("Entering state 0: TAKEOFF");

    while (ros::ok())
    {
        const ros::Time now = ros::Time::now();
        if (current_state.mode != "OFFBOARD"
            && now - last_mode_request > ros::Duration(5.0))
        {
            if (set_mode_client.call(offboard_mode) && offboard_mode.response.mode_sent)
                ROS_INFO("OFFBOARD enabled");
            last_mode_request = now;
        }
        if (!current_state.armed && now - last_arm_request > ros::Duration(5.0))
        {
            if (arming_client.call(arm_cmd) && arm_cmd.response.success)
                ROS_INFO("Vehicle armed");
            last_arm_request = now;
        }

        setPose(pose, homeHoverPoint(), init_yaw);
        local_pos_pub.publish(pose);

        const bool at_takeoff_height = std::fabs(local_pos.pose.pose.position.z
                                      - homeHoverPoint().z) < 0.20;
        if (at_takeoff_height && current_state.armed && current_state.mode == "OFFBOARD")
        {
            if (takeoff_reached_time.isZero()) takeoff_reached_time = now;
            if (now - takeoff_reached_time > ros::Duration(3.0)) break;
        }
        else
        {
            takeoff_reached_time = ros::Time();
        }

        ros::spinOnce();
        rate.sleep();
    }

    enterState(TRANSIT_START_TO_SATELLITE);
    ros::Time last_loop_time = ros::Time::now();

    while (ros::ok() && task_num != COMPLETE)
    {
        ros::spinOnce();
        const ros::Time now = ros::Time::now();
        double dt = (now - last_loop_time).toSec();
        last_loop_time = now;
        dt = clampValue(dt, 0.0, 0.20);

        if (state_entry_pending)
        {
            state_entry_pending = false;
            switch (task_num)
            {
                case TRANSIT_START_TO_SATELLITE:
                    prepareTransit(circleEntryPoint(satelliteCenter(), R_satellite_search),
                                   start_to_satellite_hook);
                    break;
                case SATELLITE_SEARCH:
                    initializeCircle(satelliteCenter());
                    ring_detect_count = 0;
                    omega_circle = -omega_base / 2.0;
                    break;
                case SATELLITE_CAPTURE:
                    initializeCircle(satelliteCenter());
                    callVoiceOnce(capture_voice_client, "正在捕获");
                    task_start_time = ros::Time::now();
                    break;
                case SATELLITE_ORBIT:
                    initializeCircle(satelliteCenter());
                    callVoiceOnce(orbit_voice_client, "正在绕飞");
                    task_start_time = ros::Time::now();
                    break;
                case TRANSIT_SATELLITE_TO_YELLOW:
                    prepareTransit(yellowSearchPoint(), satellite_to_yellow_hook);
                    break;
                case YELLOW_SEARCH:
                    commanded_yaw = yaw;
                    yellow_detect_count = 0;
                    hold_point = yellowSearchPoint();
                    break;
                case YELLOW_APPROACH:
                    commanded_position = currentPoint();
                    commanded_yaw = yaw;
                    break;
                case YELLOW_CONTACT_SPIN:
                    commanded_position = currentPoint();
                    commanded_yaw = yaw;
                    contact_forward_yaw = yaw;
                    callVoiceOnce(yellow_voice_client, "黄色气球接触动作");
                    task_start_time = ros::Time::now();
                    break;
                case TRANSIT_YELLOW_TO_HOME:
                    prepareTransit(homeHoverPoint(), yellow_to_home_hook);
                    break;
                case LAND:
                    hold_point = homeHoverPoint();
                    land_request_sent = false;
                    requestLandMode();
                    break;
                case TAKEOFF:
                case COMPLETE:
                    break;
            }
        }

        switch (task_num)
        {
            case TRANSIT_START_TO_SATELLITE:
            case TRANSIT_SATELLITE_TO_YELLOW:
            case TRANSIT_YELLOW_TO_HOME:
            {
                const MissionState transit_state = task_num;
                if (now - task_start_time > ros::Duration(transit_timeout))
                {
                    ROS_ERROR_THROTTLE(2.0, "%s timed out; holding position", stateName(task_num));
                    setPose(pose, hold_point, yaw);
                    break;
                }
                if (updateTransitPose(pose))
                {
                    if (transit_state == TRANSIT_START_TO_SATELLITE)
                        enterState(SATELLITE_SEARCH);
                    else if (transit_state == TRANSIT_SATELLITE_TO_YELLOW)
                        enterState(YELLOW_SEARCH);
                    else
                        enterState(LAND);
                }
                break;
            }

            case SATELLITE_SEARCH:
                if (ringCenteredAndFresh())
                    ++ring_detect_count;
                else
                    ring_detect_count = 0;
                if (ring_detect_count >= ring_detect_count_required)
                {
                    enterState(SATELLITE_CAPTURE);
                    break;
                }
                if (now - task_start_time > ros::Duration(satellite_search_timeout))
                    ROS_WARN_THROTTLE(5.0, "Satellite search timeout reached; continuing the configured search circle");
                omega_circle = clampValue(-omega_base / 2.0, -0.25, -0.02);
                setCirclePose(pose, satelliteCenter(), R_satellite_search, omega_circle, dt);
                break;

            case SATELLITE_CAPTURE:
                if (now - last_target_time > ros::Duration(satellite_vision_loss_timeout))
                {
                    ROS_WARN("Black ring lost during capture; returning to SATELLITE_SEARCH");
                    enterState(SATELLITE_SEARCH);
                    break;
                }
                if (now - task_start_time >= ros::Duration(satellite_capture_duration))
                {
                    enterState(SATELLITE_ORBIT);
                    break;
                }
                omega_circle = updateRingOmega(dt);
                setCirclePose(pose, satelliteCenter(), R_satellite_capture, omega_circle, dt);
                break;

            case SATELLITE_ORBIT:
                if (now - last_target_time > ros::Duration(satellite_vision_loss_timeout))
                {
                    ROS_WARN("Black ring lost during orbit; returning to SATELLITE_SEARCH");
                    enterState(SATELLITE_SEARCH);
                    break;
                }
                if (now - task_start_time >= ros::Duration(satellite_orbit_duration))
                {
                    enterState(TRANSIT_SATELLITE_TO_YELLOW);
                    break;
                }
                omega_circle = updateRingOmega(dt);
                setCirclePose(pose, satelliteCenter(), R_satellite_orbit, omega_circle, dt);
                break;

            case YELLOW_SEARCH:
                if (yellowMessageFresh())
                    ++yellow_detect_count;
                else
                    yellow_detect_count = 0;
                if (yellow_detect_count >= yellow_detect_count_required)
                {
                    enterState(YELLOW_APPROACH);
                    break;
                }
                if (now - task_start_time > ros::Duration(yellow_search_timeout))
                    ROS_WARN_THROTTLE(5.0, "Yellow search timeout reached; continuing slow yaw search");
                commanded_yaw += yellow_search_yaw_rate * dt;
                setPose(pose, hold_point, commanded_yaw);
                break;

            case YELLOW_APPROACH:
            {
                if (now - task_start_time > ros::Duration(yellow_approach_timeout))
                {
                    ROS_WARN("Yellow approach timeout; returning to YELLOW_SEARCH");
                    enterState(YELLOW_SEARCH);
                    break;
                }
                if (!yellowMessageFresh())
                {
                    setPose(pose, commanded_position, commanded_yaw);
                    if (now - last_yellow_time > ros::Duration(yellow_loss_return_timeout))
                    {
                        ROS_WARN("Yellow balloon lost; returning to YELLOW_SEARCH");
                        enterState(YELLOW_SEARCH);
                    }
                    break;
                }
                if (yellow_area_ratio >= yellow_area_contact_threshold)
                {
                    enterState(YELLOW_CONTACT_SPIN);
                    break;
                }

                const double pixel_error = yellow_target_pixel_x - yellow_target_x;
                double yaw_rate = 0.0;
                if (std::fabs(pixel_error) > yellow_center_tolerance)
                    yaw_rate = clampValue(-yellow_yaw_kp * pixel_error,
                                          -std::fabs(yellow_search_yaw_rate),
                                           std::fabs(yellow_search_yaw_rate));
                commanded_yaw += yaw_rate * dt;
                const double speed = yellow_area_ratio >= yellow_area_slow_threshold
                                   ? yellow_slow_approach_speed : yellow_approach_speed;
                commanded_position.x += speed * dt * std::cos(commanded_yaw);
                commanded_position.y += speed * dt * std::sin(commanded_yaw);
                commanded_position.z = yellowSearchPoint().z;
                setPose(pose, commanded_position, commanded_yaw);
                break;
            }

            case YELLOW_CONTACT_SPIN:
                commanded_position.x += yellow_contact_forward_speed * dt * std::cos(contact_forward_yaw);
                commanded_position.y += yellow_contact_forward_speed * dt * std::sin(contact_forward_yaw);
                commanded_yaw += yellow_contact_spin_rate * dt;
                setPose(pose, commanded_position, commanded_yaw);
                if (now - task_start_time >= ros::Duration(yellow_contact_spin_duration))
                    enterState(TRANSIT_YELLOW_TO_HOME);
                break;

            case LAND:
                setPose(pose, hold_point, init_yaw);
                if (current_state.mode != "AUTO.LAND"
                    && now - last_land_request > ros::Duration(2.0))
                    requestLandMode();
                if (land_request_sent && !current_state.armed)
                    enterState(COMPLETE);
                break;

            case TAKEOFF:
            case COMPLETE:
                break;
        }

        if (task_num != COMPLETE)
            local_pos_pub.publish(pose);

        ROS_INFO_THROTTLE(1.0,
            "state=%d(%s) pos=(%.2f,%.2f,%.2f) ring_x=%.1f yellow=(%.1f,%.3f)",
            static_cast<int>(task_num), stateName(task_num),
            local_pos.pose.pose.position.x, local_pos.pose.pose.position.y,
            local_pos.pose.pose.position.z, target_x,
            yellow_target_pixel_x, yellow_area_ratio);
        rate.sleep();
    }

    ROS_INFO("Mission complete");
    return 0;
}
